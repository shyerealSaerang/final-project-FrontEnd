// Import packages
import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.border.Border;
import java.awt.event.*;
import java.io.BufferedReader;  
import java.io.FileReader;  
import java.io.IOException;  
import javax.swing.JOptionPane;

// Create class    
public class Demo{  
	// Global variables
	JFrame frame; 
	JComboBox comboBoxBulan;
	
	// Constructor
	public Demo(){    
		// Frame Design
		frame = new JFrame("Data ODP, PDP dan Positif Covid-19");    
		
		// Banner Design
		JLabel lblBanner = new JLabel("Provinsi DKI Jakarta Per-Kecamatan Tahun 2020");
		lblBanner.setFont(new Font("Serif", Font.BOLD, 22));
		lblBanner.setBounds(10, 10, 900, 30);  
		frame.add(lblBanner);  
		
		// Label Nama Bulan
		JLabel lblBulan = new JLabel("Pilih Bulan:");
		lblBulan.setBounds(10, 50, 900, 30);  
		frame.add(lblBulan);  
		
		// Selection box Bulan
		String namaBulan[]={"Maret","April","Mei","Juni"};        
		comboBoxBulan = new JComboBox(namaBulan);    
		comboBoxBulan.setBounds(120, 55, 280, 20);    
		frame.add(comboBoxBulan);  
		
		// Label Tanggal
		JLabel lblTanggal = new JLabel("Pilih Tanggal:");
		lblTanggal.setBounds(10, 80, 900, 30);  
		frame.add(lblTanggal);  
		
		// Selection box Tanggal
		String tanggal[]={"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"};        
		JComboBox comboBoxTanggal = new JComboBox(tanggal);    
		comboBoxTanggal.setBounds(120, 85, 280, 20);    
		frame.add(comboBoxTanggal);  
		
		// Label Kecamatan
		JLabel lblKecamatan = new JLabel("Pilih Kecamatan:");
		lblKecamatan.setBounds(10, 110, 900, 30);  
		frame.add(lblKecamatan);  
		
		// Selection box Wilayah Kecamatan
		String kecamatan[]={"CAKUNG", "CEMPAKA PUTIH", "CENGKARENG", "CILANDAK", "CILINCING", "CIPAYUNG", "CIRACAS", "DUREN SAWIT", "GAMBIR", "GROGOL PETAMBURAN", "JAGAKARSA", "JATINEGARA", "JOHAR BARU", "KALI DERES", "KEBAYORAN BARU", "KEBAYORAN LAMA", "KEBON JERUK", "KELAPA GADING", "KEMAYORAN", "KEMBANGAN", "KEP. SERIBU SELATAN", "KEP. SERIBU UTARA", "KOJA", "KRAMAT JATI", "LUAR DKI JAKARTA", "MAKASAR", "MAMPANG PRAPATAN", "MATRAMAN", "MENTENG", "PADEMANGAN", "PALMERAH", "PANCORAN", "PASAR MINGGU", "PASAR REBO", "PENJARINGAN", "PESANGGRAHAN", "PULO GADUNG", "SAWAH BESAR", "SENEN", "SETIA BUDI", "TAMAN SARI", "TAMBORA", "TANAH ABANG", "TANJUNG PRIOK", "BELUM DIKETAHUI"};        
		JComboBox comboBoxKecamatan = new JComboBox(kecamatan);    
		comboBoxKecamatan.setBounds(120, 115, 280, 20);    
		frame.add(comboBoxKecamatan);  
		
		// Design Button Search
		JButton btnSearch = new JButton("Sequential Search");
		btnSearch.setBounds(420, 55, 255, 80);    
		btnSearch.setFont(new Font("Serif", Font.BOLD, 27));
		//btnSearch.setBackground(Color.RED);
		frame.add(btnSearch);
		
		//Design a Panel Border Title
		JPanel pnlBorder = new JPanel();
		Border bdrTitle = BorderFactory.createTitledBorder("Search Output");
		pnlBorder.setFont(new Font("Serif", Font.BOLD, 22));
		pnlBorder.setBounds(10, 150, 665, 300); 
		pnlBorder.setOpaque(false); // set opaque to false - background not drawn
		pnlBorder.setLayout(null); 
		pnlBorder.setBorder(bdrTitle);
		
		// Design Outputs
		JLabel lblODP = new JLabel("ODP              : ");
		lblODP.setBounds(30, 40, 200, 50);  
		lblODP.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(lblODP);  
		
		JLabel lblPDP = new JLabel("PDP              : ");
		lblPDP.setBounds(30, 120, 200, 50);  
		lblPDP.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(lblPDP);  
		
		JLabel lblPositif = new JLabel("Positif Covid : ");
		lblPositif.setBounds(30, 210, 200, 50);  
		lblPositif.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(lblPositif);  
		
		JLabel outputODP = new JLabel("0");
		outputODP.setBounds(220, 43, 100, 50);  
		outputODP.setForeground(Color.RED);
		outputODP.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(outputODP);  
		
		JLabel outputPDP = new JLabel("0");
		outputPDP.setBounds(220, 123, 100, 50);  
		outputPDP.setForeground(Color.RED);
		outputPDP.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(outputPDP);  
		
		JLabel outputPositif = new JLabel("0");
		outputPositif.setBounds(220, 213, 100, 50);  
		outputPositif.setForeground(Color.RED);
		outputPositif.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(outputPositif);  
		
		JLabel lblDirawat = new JLabel("Dirawat     : ");
		lblDirawat.setBounds(370, 40, 200, 50);  
		lblDirawat.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(lblDirawat);  
		
		JLabel lblSembuh = new JLabel("Sembuh     : ");
		lblSembuh.setBounds(370, 120, 200, 50);  
		lblSembuh.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(lblSembuh);  
		
		JLabel lblMeninggal = new JLabel("Meninggal : ");
		lblMeninggal.setBounds(370, 210, 200, 50);  
		lblMeninggal.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(lblMeninggal);  
		
		JLabel outputDirawat = new JLabel("0");
		outputDirawat.setBounds(530, 43, 100, 50);  
		outputDirawat.setForeground(Color.RED);
		outputDirawat.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(outputDirawat);  
		
		JLabel outputSembuh = new JLabel("0");
		outputSembuh.setBounds(530, 123, 100, 50);  
		outputSembuh.setForeground(Color.RED);
		outputSembuh.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(outputSembuh);  
		
		JLabel outputMeninggal = new JLabel("0");
		outputMeninggal.setBounds(530, 213, 100, 50);  
		outputMeninggal.setForeground(Color.RED);
		outputMeninggal.setFont(new Font("Serif", Font.BOLD, 30));
		pnlBorder.add(outputMeninggal);  
		
		// Button Search is clicked
		btnSearch.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
				System.out.println("Button search is clicked...!!!"); 
				String filePath = "";
				String line = "";  
				String blnNumber = "";
				boolean statusSearch = true;
				
				// Get values
				String getBulan = comboBoxBulan.getSelectedItem().toString();
				String getTanggal = comboBoxTanggal.getSelectedItem().toString();
				String getKecamatan = comboBoxKecamatan.getSelectedItem().toString();
				
				System.out.println("Bulan yang dipilih: "+getBulan); 
				System.out.println("Tanggal yang dipilih: "+getTanggal); 
				System.out.println("Kecamatan yang dipilih: "+getKecamatan); 
				
				
				// Set file berdasarkan bulan
				if(getBulan.equals("Maret")){
					filePath = "./data/data-maret.csv";
					blnNumber = "03";
				}else if(getBulan.equals("April")){
					filePath = "./data/data-april.csv";
					blnNumber = "04";
				}else if(getBulan.equals("Mei")){
					filePath = "./data/data-mei.csv";
					blnNumber = "05";
				}else if(getBulan.equals("Juni")){
					filePath = "./data/data-juni.csv";
					blnNumber = "06";
				}
				
				// Buat format tanggal yang akan dicari
				String cariTanggal = "2020-"+blnNumber+"-"+getTanggal;
				
				// Read file
				try {
					//parsing a CSV file into BufferedReader class constructor  
					BufferedReader br = new BufferedReader(new FileReader(filePath));  
					while ((line = br.readLine()) != null){    
						// use comma as separator 
						String[] data = line.split(","); 
						String dataTanggal = data[0]; // Colom pertama tanggal, index ke 0
						String dataKecamatan = data[1]; // Colom kedua kecamatan, index ke 1
						
						System.out.println("Search ... : "+line);
						//System.out.println("Cari format tanggal: "+cariTanggal);
						//System.out.println("Data format tanggal: "+dataTanggal);
						
						// Search condition
						if(cariTanggal.equals(dataTanggal) && getKecamatan.equals(dataKecamatan)){
							outputODP.setText(data[2]);
							outputPDP.setText(data[5]);
							outputPositif.setText(data[8]);
							outputDirawat.setText(data[9]);
							outputSembuh.setText(data[10]);
							outputMeninggal.setText(data[11]);
							statusSearch = true;
							break;
						}else{
							outputODP.setText("0");
							outputPDP.setText("0");
							outputPositif.setText("0");
							outputDirawat.setText("0");
							outputSembuh.setText("0");
							outputMeninggal.setText("0");
							statusSearch = false;
						}
					}
					
					// Report status jika tidak ditemukan
					if(statusSearch == false){
						JOptionPane.showMessageDialog(null, "Maaf, data yang anda cari tidak ditemukan.","Pencarian Gagal",JOptionPane.ERROR_MESSAGE); 
					}
						
				}catch (IOException ex) {  
					ex.printStackTrace();  
				}  
			} 
		} );

		
		// Frame properties
		frame.add(pnlBorder);
		frame.setResizable(false);
		frame.setLayout(null);    
		frame.setSize(700, 500); // Frame with fixed size
		frame.setVisible(true);   
		frame.setLocationRelativeTo(null); // JFrame center on screen
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(Color.ORANGE);
	}    
	

	public static void main(String[] args) {    
		new Demo();         
	}    
	} 